@echo off
setlocal EnableExtensions
title Nexoti Uninstaller

REM -- Elevar a administrador --
>nul 2>&1 net session
if %errorlevel% neq 0 (
  powershell -NoProfile -Command "Start-Process -Verb RunAs -FilePath '%~f0'"
  exit /b
)

set "AGENT_DIR=%ProgramData%\Soporteia\Agent"
set "STARTUP_LNK=%ProgramData%\Microsoft\Windows\Start Menu\Programs\StartUp\Nexoti-Overlay.lnk"

echo [1/5] Deteniendo overlay(s)...
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*overlay-wpf.ps1*' } | ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force } catch {} }"

echo [2/5] Eliminando inicio automatico...
if exist "%STARTUP_LNK%" del /f /q "%STARTUP_LNK%" >NUL 2>&1

echo [3/5] Eliminando tareas programadas...
schtasks /End /TN SoporteiaAgent >NUL 2>&1
schtasks /Delete /TN SoporteiaAgent /F >NUL 2>&1
schtasks /Delete /TN NexotiOverlay /F >NUL 2>&1

echo [4/5] Eliminando archivos del agente...
if exist "%AGENT_DIR%" rmdir /s /q "%AGENT_DIR%"

echo [5/5] Limpieza finalizada.
mshta "javascript:alert('Nexoti desinstalado correctamente');close()"
exit /b 0
