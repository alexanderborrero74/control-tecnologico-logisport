@echo off
setlocal EnableExtensions

REM ==== 0) Auto-elevación a Administrador (sin mensajes) ====
>nul 2>&1 net session
if %errorlevel% neq 0 (
  powershell -NoProfile -Command "Start-Process -Verb RunAs -WindowStyle Hidden -FilePath '%~f0'"
  exit /b
)

REM ==== 1) Rutas y parámetros por defecto ====
set "SCRIPT_DIR=%~dp0"
set "CORE=%SCRIPT_DIR%install-core.ps1"

if not exist "%CORE%" (
  powershell -NoProfile -Command "mshta 'javascript:alert(`'No se encontró install-core.ps1 en la misma carpeta.`');close()'"
  exit /b 1
)

set "BASEURL=https://sidecomex.vercel.app"
set "CLIENTID=AGENCIA DE ADUANAS SIDECOMEX"
set "TOKEN=2249902f50c60cc925c10d75c9406fc44c958cbe6a45f90765e40136a4431a496da6952786973b7d41cd8998cb9550f9"
set "MINUTES=5"
set "BRAND=Equipo Monitoreado Por NexoTi. Alexander Borrero. Soporteia.net"

REM ==== 2) Logo opcional junto al instalador ====
set "LOGO="
for %%F in ("logo.png" "branding.png" "logo soporteianet.png") do (
  if exist "%SCRIPT_DIR%%%~F" set "LOGO=%SCRIPT_DIR%%%~F"
)

REM ==== 3) Ejecutar el core en modo oculto (sin textos ni pausas) ====
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%CORE%" ^
  -BaseUrl "%BASEURL%" -ClientId "%CLIENTID%" -Token "%TOKEN%" -Minutes %MINUTES% ^
  -BrandText "%BRAND%" -LogoFile "%LOGO%" -LogoPx 20

if errorlevel 1 (
  powershell -NoProfile -Command "mshta 'javascript:alert(`'Ocurrió un error durante la instalación. Revise C:\\ProgramData\\Soporteia\\Agent\\install.log`');close()'"
  exit /b 1
)

REM Éxito: el core ya muestra su mensaje “Instalacion Monitoreo de NexoTi exitosa”
exit /b 0
