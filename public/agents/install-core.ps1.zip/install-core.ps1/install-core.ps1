﻿param(
  [string]$BaseUrl   = $env:SOPORTEIA_BASE_URL,
  [string]$ClientId  = $env:SOPORTEIA_CLIENT_ID,
  [string]$Token     = $env:SOPORTEIA_INGEST_TOKEN,
  [int]   $Minutes   = 5,
  [string]$BrandText = "Equipo Monitoreado Por NexoTi. Alexander Borrero. Soporteia.net",
  [string]$LogoFile  = "",
  # tamaños por defecto
  [int]   $LogoPx    = 20,
  [int]   $FontPx    = 10,
  [int]   $MaxWidth  = 200,
  [int]   $MarginX   = 21,
  [int]   $MarginY   = 670
)

# ======================================================
# INSTALADOR + AGENTE COMPLETO (mantiene toda la lógica)
# Versión instalador: 2.3.2  (micro‑diff respecto a 2.3.0)
# Cambios mínimos:
#  - BEGIN PATCH #1: Dedupe de apagados (6008) con timestamp exacto.
#  - BEGIN PATCH #2: Lectura y envío de temperatura CPU (°C).
#  - BEGIN PATCH #3: Envío de unexpectedShutdownAt en el body.
#  - No se eliminó ninguna sección: carpetas, logo, overlay, tarea, etc.
# ======================================================

$ErrorActionPreference = 'Stop'

# ===== Rutas =====
$ProgData   = $env:ProgramData
$AgentDir   = Join-Path $ProgData "Soporteia\Agent"
$LogFile    = Join-Path $AgentDir "install.log"
$AgentPS1   = Join-Path $AgentDir "agent.ps1"
$WrapperCMD = Join-Path $AgentDir "run-agent.cmd"
$OverlayPS1 = Join-Path $AgentDir "overlay-wpf.ps1"
$OverlayLnk = Join-Path $ProgData "Microsoft\Windows\Start Menu\Programs\StartUp\Nexoti-Overlay.lnk"
$BrandPng   = Join-Path $AgentDir "branding.png"

function Write-Log($m){ $ts=Get-Date -Format "yyyy-MM-dd HH:mm:ss"; Add-Content -Path $LogFile -Value "$ts  $m" }

# 1) Carpetas
New-Item -ItemType Directory -Force -Path $AgentDir | Out-Null
"Instalacion iniciada" | Out-File -FilePath $LogFile -Encoding UTF8

# 2) Logo (opcional)
try {
  if ([string]::IsNullOrWhiteSpace($LogoFile)) {
    $callerDir = Split-Path -Parent $PSCommandPath
    foreach($n in @("logo.png","branding.png","logo soporteianet.png")){
      $cand = Join-Path $callerDir $n
      if (Test-Path $cand) { $LogoFile = $cand; break }
    }
  }
  if ($LogoFile -and (Test-Path $LogoFile)) {
    Copy-Item -Force $LogoFile $BrandPng
    Write-Log "Logo copiado: $LogoFile -> $BrandPng"
  } else {
    $b64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR4nGNgYAAAAAMAAWgmWQ0AAAAASUVORK5CYII="
    [IO.File]::WriteAllBytes($BrandPng,[Convert]::FromBase64String($b64))
    Write-Log "Logo fallback base64 escrito."
  }
} catch { Write-Log "WARN Logo: $($_.Exception.Message)" }

# 3) Agente (ACTUALIZADO v2.3.2) — se mantiene estructura original
try {
$agentSrc = @'
param(
  [string]$BaseUrl  = $env:SOPORTEIA_BASE_URL,
  [string]$ClientId = $env:SOPORTEIA_CLIENT_ID,
  [string]$Token    = $env:SOPORTEIA_INGEST_TOKEN
)
if ([string]::IsNullOrWhiteSpace($BaseUrl))  { $BaseUrl  = "__BASEURL__" }
if ([string]::IsNullOrWhiteSpace($ClientId)) { $ClientId = "__CLIENTID__" }
if ([string]::IsNullOrWhiteSpace($Token))    { $Token    = "__TOKEN__" }

$AgentVersion = "2.3.2"
$AgentDir = Join-Path $env:ProgramData "Soporteia\Agent"
$LogPath  = Join-Path $AgentDir "agent.log"
if (!(Test-Path $AgentDir)) { New-Item -Force -ItemType Directory -Path $AgentDir | Out-Null }

function Write-Log($msg) { $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"; Add-Content -Path $LogPath -Value "$ts  $msg" }

# -------- Helpers (sin cambios funcionales salvo PATCHs) --------
function Get-OfficeInfo {
  function NullIfEmpty([string]$s) { if ([string]::IsNullOrWhiteSpace($s)) { $null } else { $s } }
  try {
    $ctr = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration' -ErrorAction Stop
    $ver = if ($ctr.VersionToReport) { $ctr.VersionToReport } elseif ($ctr.ClientVersionToReport) { $ctr.ClientVersionToReport } else { $null }
    $prod = NullIfEmpty $ctr.ProductReleaseIds
    $plat = NullIfEmpty $ctr.Platform
    $cdn  = if ($ctr.UpdateChannel) { $ctr.UpdateChannel } elseif ($ctr.CDNBaseUrl) { $ctr.CDNBaseUrl } else { $null }
    $channel = $null
    if ($cdn) {
      $cdnLower = $cdn.ToLower()
      if ($cdnLower -match 'monthlyenterprise') { $channel = 'Monthly Enterprise' }
      elseif ($cdnLower -match 'monthly|current') { $channel = 'Current' }
      elseif ($cdnLower -match 'semi-?annual|targeted') { $channel = 'Semi-Annual' }
      else { $channel = $cdn }
    }
    $edition = $null
    if ($prod) {
      if ($prod -match 'O365ProPlus|ProPlusRetail|Mondo') { $edition = 'Microsoft 365 Apps (ProPlus)' }
      elseif ($prod -match 'Business') { $edition = 'Microsoft 365 Apps (Business)' }
      elseif ($prod -match 'Home|Student|Personal') { $edition = 'Home/Student/Personal' }
    }
    if ($ver) {
      return [pscustomobject]@{
        Source='ClickToRun'; Version=$ver; Edition=$edition; Channel=$channel; Architecture=$plat; Product=$prod
      }
    }
  } catch {}
  try {
    $paths = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')
    $candidates = foreach ($p in $paths) {
      Get-ItemProperty $p -ErrorAction SilentlyContinue | Where-Object {
        $_.DisplayName -match 'Microsoft (365|Office)' -or $_.DisplayName -match 'Office (19|20|LTSC|Professional|Standard)'
      }
    }
    if ($candidates) {
      $best = $candidates | Sort-Object { try { [version]($_.DisplayVersion) } catch { [version]'0.0.0.0' } } -Descending | Select-Object -First 1
      if ($best) {
        $ver = if ($best.DisplayVersion) { $best.DisplayVersion } else { $null }
        $name = $best.DisplayName
        return [pscustomobject]@{ Source='MSI/Uninstall'; Version=$(if ($ver) { $ver } else { $name }); Edition=$name; Channel=$null; Architecture=$null; Product=$name }
      }
    }
  } catch {}
  return [pscustomobject]@{ Source='NotFound'; Version=$null; Edition=$null; Channel=$null; Architecture=$null; Product=$null }
}

function Get-FolderSizeMB([string]$Path){
  try {
    if ([string]::IsNullOrWhiteSpace($Path) -or !(Test-Path -LiteralPath $Path)) { return $null }
    $sum = 0
    Get-ChildItem -LiteralPath $Path -Recurse -Force -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer } | ForEach-Object { $sum += [int64]$_.Length }
    return [int]([math]::Round($sum / 1MB))
  } catch { return $null }
}

function Get-DisksWithType {
  $out = @()
  try {
    $logical = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" -ErrorAction Stop
    foreach($ld in $logical){
      $sizeMb=$null; $freeMb=$null; $freePct=$null
      if ($ld.Size)     { $sizeMb = [int]([math]::Round($ld.Size / 1MB)) }
      if ($ld.FreeSpace){ $freeMb = [int]([math]::Round($ld.FreeSpace / 1MB)) }
      if ($sizeMb -and $freeMb -ne $null -and $sizeMb -gt 0) { $freePct = [math]::Round(($freeMb / [double]$sizeMb)*1000)/10.0 }
      $type='—'; $isSSD=$null; $bus=$null; $media=$null; $model=$null
      try {
        $parts = Get-CimAssociatedInstance -InputObject $ld -ResultClassName Win32_DiskPartition -ErrorAction Stop
        $drv=$null
        if ($parts) {
          foreach($p in $parts){ $drv = Get-CimAssociatedInstance -InputObject $p -ResultClassName Win32_DiskDrive -ErrorAction Stop | Select-Object -First 1; if ($drv){ break } }
        }
        if ($drv){
          $bus=$drv.InterfaceType; $media=$drv.MediaType; $model=$drv.Model; $isSSD=$false
          $txt = "$media $model $bus"
          if ($txt -match '(?i)\bSSD\b' -or $txt -match '(?i)\bNVMe\b' -or $txt -match '(?i)Solid State') { $isSSD = $true }
          $type = if ($isSSD -eq $true) { 'SSD' } elseif ($isSSD -eq $false) { 'HDD' } else { '—' }
        }
      } catch {}
      $out += @{ name=$ld.DeviceID; letter=$ld.DeviceID; sizeMb=$sizeMb; freeMb=$freeMb; freePct=$freePct; health=$null; type=$type; isSSD=$isSSD; busType=$bus; mediaType=$media; model=$model }
    }
  } catch {}
  return $out
}

function Get-CpuInfo {
  $cpu=$null; try { $cpu = Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1 } catch {}
  if (-not $cpu) { return $null }
  $vendorRaw = $cpu.Manufacturer; $brand = $vendorRaw
  if ($vendorRaw) { $low = $vendorRaw.ToLower(); if ($low -match 'intel') { $brand='Intel' } elseif ($low -match 'amd') { $brand='AMD' } elseif ($low -match 'arm') { $brand='ARM' } }
  return [pscustomobject]@{ name=$cpu.Name; vendor=$brand; rawVendor=$vendorRaw; cores=$cpu.NumberOfCores; threads=$cpu.NumberOfLogicalProcessors; maxMHz=$cpu.MaxClockSpeed; id=$cpu.ProcessorId }
}

# BEGIN PATCH #2: Temperatura CPU (múltiples fuentes, tolerante a fallos)
function Get-CpuTempC {
  $vals = @()
  try {
    $s = Get-CimInstance -Namespace 'root/LibreHardwareMonitor' -ClassName 'Sensor' -ErrorAction Stop |
      Where-Object { $_.SensorType -eq 'Temperature' -and ($_.Name -match 'CPU|Package|Core' -or $_.Identifier -match '/cpu') }
    foreach($x in $s){ if ($x.Value -ne $null) { $vals += [double]$x.Value } }
  } catch {}
  try {
    $s = Get-CimInstance -Namespace 'root/OpenHardwareMonitor' -ClassName 'Sensor' -ErrorAction Stop |
      Where-Object { $_.SensorType -eq 'Temperature' -and ($_.Name -match 'CPU|Package|Core' -or $_.Identifier -match '/cpu') }
    foreach($x in $s){ if ($x.Value -ne $null) { $vals += [double]$x.Value } }
  } catch {}
  try {
    $t = Get-CimInstance -Namespace 'root/wmi' -ClassName 'MSAcpi_ThermalZoneTemperature' -ErrorAction Stop
    foreach($x in $t){ $k10 = $x.CurrentTemperature; if ($k10) { $c = [double]$k10/10 - 273.15; if ($c -gt -20 -and $c -lt 150) { $vals += $c } } }
  } catch {}
  try {
    $p = Get-CimInstance -Namespace 'root/cimv2' -ClassName 'Win32_TemperatureProbe' -ErrorAction Stop
    foreach($x in $p){ if ($x.CurrentReading) { $c = [double]$x.CurrentReading/10 - 273.15; if ($c -gt -20 -and $c -lt 150) { $vals += $c } } }
  } catch {}
  if ($vals.Count -gt 0) { $max = ($vals | Measure-Object -Maximum).Maximum; return [int][math]::Round($max) }
  return $null
}
# END PATCH #2

function Get-SerialAndChassis {
  $serial=$null
  try { $serial = (Get-CimInstance Win32_BIOS -ErrorAction Stop).SerialNumber } catch {}
  if (-not $serial) { try { $serial = (Get-CimInstance Win32_ComputerSystemProduct -ErrorAction Stop).IdentifyingNumber } catch {} }
  if (-not $serial) { try { $serial = (Get-CimInstance Win32_BaseBoard -ErrorAction Stop).SerialNumber } catch {} }

  $isLaptop=$false; $typesArr=$null
  try {
    $enc = Get-CimInstance Win32_SystemEnclosure -ErrorAction Stop | Select-Object -First 1
    if ($enc -and $enc.ChassisTypes) {
      $typesArr = @($enc.ChassisTypes)
      $mobileSet = @(8,9,10,14,30,31)
      if ($typesArr | Where-Object { $_ -in $mobileSet }) { $isLaptop = $true }
    } else {
      $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
      $m = ($cs.Model + " " + $cs.SystemType)
      if ($m -match '(?i)Laptop|Notebook|Portable|Tablet|Convertible') { $isLaptop = $true }
    }
  } catch {}
  return [pscustomobject]@{ serial=$serial; isLaptop=$isLaptop; chassisTypes=$typesArr }
}

# ========================================
# BEGIN PATCH #1: APAGADO INESPERADO (6008) con dedupe + hora exacta
# ========================================
$script:UnexpectedShutdownAtIso = $null
function Detect-UnexpectedShutdown {
  try {
    $event = Get-WinEvent -LogName System -FilterXPath "*[System[(EventID=6008)]]" -MaxEvents 1 -ErrorAction Stop
    if ($event) {
      $lastShutdown = $event.TimeCreated
      $boot        = (Get-CimInstance Win32_OperatingSystem).LastBootUpTime
      $stateFile   = Join-Path $env:ProgramData "Soporteia\Agent\last_shutdown.txt"
      $previous    = if (Test-Path $stateFile) { Get-Content $stateFile -Raw } else { "" }
      $currentIso  = $lastShutdown.ToUniversalTime().ToString("o")
      if ($lastShutdown -gt $boot.AddMinutes(-10) -and $currentIso -ne $previous) {
        Set-Content -Path $stateFile -Value $currentIso -Encoding ascii
        $script:UnexpectedShutdownAtIso = $currentIso
        Write-Log "⚠️  Apagado inesperado NUEVO ($currentIso UTC)"
        return $true
      } else {
        Write-Log "6008 ya reportado (prev=$previous | now=$currentIso)"
      }
    }
  } catch {
    Write-Log "Error detectando 6008: $_"
  }
  return $false
}
# END PATCH #1

try {
  $deviceId = $env:COMPUTERNAME; $hostname = $env:COMPUTERNAME; $username = $env:USERNAME

  $osObj = $null; try { $osObj = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop } catch { }
  $osCaption = if ($osObj -and $osObj.Caption) { [string]$osObj.Caption } else { "Windows" }
  $uptimeMin = $null
  try {
    if ($osObj -and $osObj.LastBootUpTime) {
      $boot = [System.Management.ManagementDateTimeConverter]::ToDateTime($osObj.LastBootUpTime)
      $uptimeMin = [int]([DateTime]::UtcNow - $boot.ToUniversalTime()).TotalMinutes
      if ($uptimeMin -lt 0) { $uptimeMin = $null }
    }
  } catch { $uptimeMin = $null }

  $cpuLoadPct = $null
  try {
    $p = Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -ExpandProperty LoadPercentage -ErrorAction Stop
    $avg = ($p | Measure-Object -Average).Average
    if ($avg -ne $null) { $cpuLoadPct = [int][Math]::Round($avg) }
  } catch { }
  if ($cpuLoadPct -eq $null) {
    try {
      $samples = (Get-Counter '\\Processor(_Total)\\% Processor Time' -SampleInterval 1 -MaxSamples 2).CounterSamples
      $last = $samples | Select-Object -Last 1
      if ($last -and $last.CookedValue -ne $null) { $cpuLoadPct = [int][Math]::Round([Math]::Min([Math]::Max($last.CookedValue,0),100)) }
    } catch { }
  }

  $cs = $null; $os2 = $null
  try { $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop } catch { }
  try { $os2 = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop } catch { }
  $totalMb = $null; $freeMb = $null; $usedMb = $null; $usedPct = $null
  if ($cs -and $cs.TotalPhysicalMemory) { $totalMb = [int]([math]::Round($cs.TotalPhysicalMemory / 1MB)) }
  if ($os2 -and $os2.FreePhysicalMemory) { $freeMb = [int]([math]::Round(($os2.FreePhysicalMemory * 1KB) / 1MB)) }
  if ($totalMb -ne $null -and $freeMb -ne $null) {
    $usedMb = [int]([math]::Max(0, $totalMb - $freeMb))
    $usedPct = [int]([math]::Round(($usedMb / [double]$totalMb) * 100))
    if ($usedPct -gt 100) { $usedPct = 100 }
    if ($usedPct -lt 0)   { $usedPct = 0 }
  }

  $man = $null; $model = $null
  try { $cs2 = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop; $man = $cs2.Manufacturer; $model = $cs2.Model } catch { }
  if ([string]::IsNullOrWhiteSpace($man))   { $man = $null }
  if ([string]::IsNullOrWhiteSpace($model)) { $model = $null }

  $disks = Get-DisksWithType

  $battery = @{ status = "N/A"; percent = $null }
  try {
    $bat = Get-CimInstance Win32_Battery -ErrorAction Stop | Select-Object -First 1
    if ($bat) {
      $pct = $bat.EstimatedChargeRemaining
      if ($pct -ne $null) { if ($pct -lt 0) { $pct=0 } if ($pct -gt 100) { $pct=100 }; $battery.percent=[int]$pct; $battery.status=(if ($pct -lt 20) { "Low" } else { "OK" }) }
    }
  } catch { }

  $tempPaths = @()
  if ($env:TEMP) { $tempPaths += $env:TEMP }
  if ($env:TeMP)  { $tempPaths += $env:TeMP }
  $tempPaths += (Join-Path $env:WINDIR 'Temp')
  $tempPaths = $tempPaths | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique
  $tempTotalMB = 0
  foreach($tp in $tempPaths){ $sz = Get-FolderSizeMB $tp; if ($sz -ne $null) { $tempTotalMB += $sz } }

  $deskTotalMB = 0
  try {
    $usersDir = 'C:\\Users'
    if (Test-Path $usersDir) {
      Get-ChildItem $usersDir -Directory -ErrorAction SilentlyContinue | ForEach-Object {
        $dp = Join-Path $_.FullName 'Desktop'
        $sz = Get-FolderSizeMB $dp
        if ($sz -ne $null) { $deskTotalMB += $sz }
      }
    }
    $pubDesk = 'C:\\Users\\Public\\Desktop'
    $szp = Get-FolderSizeMB $pubDesk
    if ($szp -ne $null) { $deskTotalMB += $szp }
  } catch {}

  $officeInfo = Get-OfficeInfo
  $cpuInfo   = Get-CpuInfo
  $idChassis = Get-SerialAndChassis

  $unexpectedShutdown = Detect-UnexpectedShutdown

  # BEGIN PATCH #2 (uso)
  $cpuTempC = Get-CpuTempC
  # END PATCH #2

  $tags = @("windows","nexoti")
  $body = @{
    clientId = $ClientId
    deviceId = $deviceId
    hostname = $hostname
    username = $username
    os = $osCaption
    unexpectedShutdown = $unexpectedShutdown

    manufacturer = $man
    brand = $man
    model = $model

    serial = $idChassis.serial
    device = @{ isLaptop = $idChassis.isLaptop; chassisTypes = $idChassis.chassisTypes }

    uptimeMin = $uptimeMin

    cpuLoadPct = $cpuLoadPct

    cpu = @{ name=$cpuInfo.name; vendor=$cpuInfo.vendor; rawVendor=$cpuInfo.rawVendor; cores=$cpuInfo.cores; threads=$cpuInfo.threads; maxMHz=$cpuInfo.maxMHz; id=$cpuInfo.id; tempC=$cpuTempC }
    cpuName   = $cpuInfo.name
    cpuVendor = $cpuInfo.vendor
    cpuTempC  = $cpuTempC

    memory = @{ totalMb=$totalMb; usedMb=$usedMb; usedPct=$usedPct }
    storage = @{ disks=$disks }
    battery = $battery
    temp = @{ sizeMB = $tempTotalMB }
    desktop = @{ sizeMB = $deskTotalMB }
    office = @{
      version = $officeInfo.Version
      edition = $officeInfo.Edition
      channel = $officeInfo.Channel
      arch    = $officeInfo.Architecture
      product = $officeInfo.Product
    }
    software = @{ officeVersion = $officeInfo.Version }
    tags = $tags
    agentVersion = $AgentVersion
    timestampUtc = (Get-Date).ToUniversalTime().ToString("o")
  }

  # BEGIN PATCH #3: incluir la hora exacta del 6008
  if ($unexpectedShutdown -and $script:UnexpectedShutdownAtIso) {
    $body.unexpectedShutdownAt = $script:UnexpectedShutdownAtIso
  }
  # END PATCH #3

  $ingest = "$BaseUrl/api/agent-ingest"
  Write-Log ("POST -> {0}  deviceId={1}" -f $ingest, $deviceId)
  $json = $body | ConvertTo-Json -Depth 12 -Compress
  $resp = Invoke-RestMethod -Uri $ingest -Method POST -Headers @{ "x-agent-token" = $Token } -ContentType "application/json" -Body $json -TimeoutSec 30
  if ($resp -and $resp.ok -eq $true) { $iv = if ($resp.interval) { $resp.interval } else { "" }; Write-Log ("OK. interval={0}" -f $iv); "OK -> $ingest" } else { Write-Log "ERROR: invalid response"; throw "Invalid response" }
}
catch { $err = $_.Exception.Message; Write-Log ("ERROR: {0}" -f $err); throw }
'@

# Sustituciones de placeholders
$agentSrc = $agentSrc.Replace("__BASEURL__",$BaseUrl).Replace("__CLIENTID__",$ClientId).Replace("__TOKEN__",$Token)
Set-Content -Path $AgentPS1 -Value $agentSrc -Encoding ASCII

# Wrapper
$wrap = '@echo off' + "`r`n" + '"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -File "%ProgramData%\Soporteia\Agent\agent.ps1"'
Set-Content -Path $WrapperCMD -Value $wrap -Encoding ASCII
Write-Log "Agente escrito."
} catch { Write-Log "ERROR agente: $($_.Exception.Message)"; throw }

# 4) Tarea programada (se mantiene igual)
try {
  schtasks /Delete /TN SoporteiaAgent /F | Out-Null 2>$null
  schtasks /Create /SC MINUTE /MO $Minutes /TN SoporteiaAgent /TR "`"%ProgramData%\Soporteia\Agent\run-agent.cmd`"" /RU SYSTEM /RL HIGHEST /F | Out-Null
  Import-Module ScheduledTasks
  $s=New-ScheduledTaskSettingsSet -Compatibility Win8 -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -MultipleInstances IgnoreNew
  Set-ScheduledTask -TaskName 'SoporteiaAgent' -Settings $s | Out-Null
  Write-Log "Tarea SoporteiaAgent creada."
} catch { Write-Log "ERROR tarea: $($_.Exception.Message)"; throw }

# 5) Overlay WPF (sin cambios salvo parámetros)
try {
$ov = @'
param(
  [string]$BrandText = "__BRAND__",
  [string]$ImagePath = "$env:ProgramData\Soporteia\Agent\branding.png",
  [int]$MarginX = __MARGIN_X__,
  [int]$MarginY = __MARGIN_Y__,
  [int]$LogoPx  = __LOGO_PX__,
  [int]$FontPx  = __FONT_PX__,
  [int]$MaxWidth= __MAX_WIDTH__
)
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

$window = New-Object System.Windows.Window
$window.Topmost = $true
$window.WindowStyle = 'None'
$window.ResizeMode = 'NoResize'
$window.AllowsTransparency = $true
$window.Background = [System.Windows.Media.Brushes]::Transparent
$window.ShowInTaskbar = $false
$window.SizeToContent = 'WidthAndHeight'
$window.UseLayoutRounding = $true
$window.SnapsToDevicePixels = $true

$root = New-Object System.Windows.Controls.StackPanel
$root.Orientation = 'Horizontal'
$root.Margin = '0'
$root.HorizontalAlignment = 'Left'
$root.VerticalAlignment = 'Top'

if (Test-Path $ImagePath) {
  try {
    $imgBorder = New-Object System.Windows.Controls.Border
    $imgBorder.Width  = $LogoPx
    $imgBorder.Height = $LogoPx
    $imgBorder.Background = [System.Windows.Media.Brushes]::Transparent
    $imgBorder.SnapsToDevicePixels = $true
    $imgBorder.UseLayoutRounding = $true
    $imgBorder.ClipToBounds = $true
    $imgBorder.Margin = '0,0,6,0'

    $img = New-Object System.Windows.Controls.Image
    $bmp = New-Object System.Windows.Media.Imaging.BitmapImage
    $bmp.BeginInit()
    $bmp.UriSource = New-Object System.Uri($ImagePath)
    $bmp.DecodePixelWidth  = $LogoPx
    $bmp.DecodePixelHeight = $LogoPx
    $bmp.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
    $bmp.CreateOptions = [System.Windows.Media.Imaging.BitmapCreateOptions]::IgnoreColorProfile
    $bmp.EndInit()

    $img.Source = $bmp
    $img.Width  = $LogoPx
    $img.Height = $LogoPx
    $img.Stretch = 'Uniform'
    $img.HorizontalAlignment = 'Center'
    $img.VerticalAlignment   = 'Center'
    [System.Windows.Media.RenderOptions]::SetBitmapScalingMode($img,[System.Windows.Media.BitmapScalingMode]::LowQuality)

    $imgBorder.Child = $img
    $root.Children.Add($imgBorder) | Out-Null
  } catch { }
}

$border = New-Object System.Windows.Controls.Border
$border.CornerRadius = '8'
$border.Background = New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.Color]::FromArgb(160, 52, 152, 219))
$border.Padding = '6,3,6,3'

$tb = New-Object System.Windows.Controls.TextBlock
$tb.Text = $BrandText
$tb.FontSize = $FontPx
$tb.FontWeight = 'Bold'
$tb.Foreground = [System.Windows.Media.Brushes]::White
$tb.TextWrapping = 'Wrap'
$tb.MaxWidth = $MaxWidth
$border.Child = $tb

$root.Children.Add($border) | Out-Null
$window.Content = $root

$window.Add_Loaded({
  $wa = [System.Windows.SystemParameters]::WorkArea
  $window.Left = $wa.Right - $window.ActualWidth - $MarginX
  $window.Top  = $wa.Top + $MarginY
})

$timer = New-Object System.Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromSeconds(5)
$timer.add_Tick({ $window.Topmost = $true })
$timer.Start()

[void]$window.ShowDialog()
'@

$ov = $ov.Replace("__BRAND__",     $BrandText)
$ov = $ov.Replace("__LOGO_PX__",   [string]$LogoPx)
$ov = $ov.Replace("__FONT_PX__",   [string]$FontPx)
$ov = $ov.Replace("__MAX_WIDTH__", [string]$MaxWidth)
$ov = $ov.Replace("__MARGIN_X__",  [string]$MarginX)
$ov = $ov.Replace("__MARGIN_Y__",  [string]$MarginY)

Set-Content -Path $OverlayPS1 -Value $ov -Encoding ASCII
Write-Log "Overlay escrito (logo %${LogoPx}px%)."
} catch { Write-Log "ERROR overlay: $($_.Exception.Message)"; throw }

# 6) Inicio automático (se mantiene)
try {
  $Startup = Join-Path $ProgData 'Microsoft\Windows\Start Menu\Programs\StartUp'
  New-Item -ItemType Directory -Force -Path $Startup | Out-Null
  $wsh = New-Object -ComObject WScript.Shell
  $s = $wsh.CreateShortcut($OverlayLnk)
  $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  $s.TargetPath = $ps
  $s.Arguments  = '-STA -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + $OverlayPS1 + '"'
  $s.WorkingDirectory = $AgentDir
  $s.IconLocation = "$env:SystemRoot\system32\shell32.dll,44"
  $s.Save()
  Write-Log "Startup LNK creado."
} catch {
  Write-Log "ERROR startup link: $($_.Exception.Message)"
  try {
    $cmd = '"' + (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') + '" -STA -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + $OverlayPS1 + '"'
    schtasks /Create /SC ONLOGON /TN NexotiOverlay /TR "$cmd" /RL HIGHEST /F | Out-Null
    Write-Log "Fallback ONLOGON creado."
  } catch { Write-Log "ERROR fallback ONLOGON: $($_.Exception.Message)" }
}

# 7) Reiniciar overlay + primer envío (se mantiene)
try {
  Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*overlay-wpf.ps1*' } | ForEach-Object {
    try { Stop-Process -Id $_.ProcessId -Force } catch {}
  }
  Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') -ArgumentList @('-STA','-NoProfile','-WindowStyle','Hidden','-ExecutionPolicy','Bypass','-File',"`"$OverlayPS1`"") -WindowStyle Hidden
  Write-Log "Overlay relanzado."
} catch { Write-Log "ERROR relanzando overlay: $($_.Exception.Message)" }

try { schtasks /Run /TN SoporteiaAgent | Out-Null; Write-Log "Tarea SoporteiaAgent ejecutada." } catch { Write-Log "ERROR run tarea: $($_.Exception.Message)" }

# 8) Mensaje final (igual)
try {
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show("Instalacion Monitoreo de NexoTi exitosa","Nexoti",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
} catch {
  Start-Process mshta "javascript:alert('Instalacion Monitoreo de NexoTi exitosa');close()" -WindowStyle Hidden
}

Write-Log "OK."
exit 0
