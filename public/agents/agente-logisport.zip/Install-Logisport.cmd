@echo off
:: ============================================================
::  Instalador Agente NexoTI - LOGISPORT
::  Configurado para enviar datos a logisport.vercel.app
:: ============================================================

set SOPORTEIA_BASE_URL=https://logisport.vercel.app
set SOPORTEIA_CLIENT_ID=LOGISPORT
set SOPORTEIA_INGEST_TOKEN=logisport2025nexoti

echo Instalando agente de monitoreo NexoTI para LOGISPORT...
echo URL: %SOPORTEIA_BASE_URL%
echo Cliente: %SOPORTEIA_CLIENT_ID%
echo.

:: Buscar el .ps1 en la misma carpeta que este .cmd
set PS1_PATH=%~dp0install-core.ps1

:: Si no esta en la misma carpeta, buscar en subcarpeta install-core.ps1
if not exist "%PS1_PATH%" (
  set PS1_PATH=%~dp0install-core.ps1\install-core.ps1
)

if not exist "%PS1_PATH%" (
  echo ERROR: No se encontro install-core.ps1
  echo Asegurate de descomprimir el zip completo antes de ejecutar este archivo.
  pause
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1_PATH%" ^
  -BaseUrl "%SOPORTEIA_BASE_URL%" ^
  -ClientId "%SOPORTEIA_CLIENT_ID%" ^
  -Token "%SOPORTEIA_INGEST_TOKEN%" ^
  -BrandText "Equipo monitoreado por NexoTI - LOGISPORT" ^
  -Minutes 5

if %ERRORLEVEL% NEQ 0 (
  echo ERROR: La instalacion fallo. Revisa install.log en C:\ProgramData\Soporteia\Agent\
  pause
  exit /b 1
)

echo.
echo Instalacion completada exitosamente.
pause
